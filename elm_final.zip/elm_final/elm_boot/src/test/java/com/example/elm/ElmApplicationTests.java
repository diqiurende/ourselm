package com.example.elm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElmApplicationTests {

    @Test
    void contextLoads() {
    }

}
